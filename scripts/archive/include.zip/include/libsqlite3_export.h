
#ifndef SQLITE_API_H
#define SQLITE_API_H

#ifdef SQLITE3_STATIC
#  define SQLITE_API
#  define LIBSQLITE3_NO_EXPORT
#else
#  ifndef SQLITE_API
#    ifdef libsqlite3_EXPORTS
        /* We are building this library */
#      define SQLITE_API __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define SQLITE_API __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBSQLITE3_NO_EXPORT
#    define LIBSQLITE3_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBSQLITE3_DEPRECATED
#  define LIBSQLITE3_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBSQLITE3_DEPRECATED_EXPORT
#  define LIBSQLITE3_DEPRECATED_EXPORT SQLITE_API LIBSQLITE3_DEPRECATED
#endif

#ifndef LIBSQLITE3_DEPRECATED_NO_EXPORT
#  define LIBSQLITE3_DEPRECATED_NO_EXPORT LIBSQLITE3_NO_EXPORT LIBSQLITE3_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBSQLITE3_NO_DEPRECATED
#    define LIBSQLITE3_NO_DEPRECATED
#  endif
#endif

#endif /* SQLITE_API_H */
